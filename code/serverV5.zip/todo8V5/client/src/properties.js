export default {
  GEOSERVER_URL: process.env.VUE_APP_GEOSERVER_URL,

  SERVER_URL: process.env.VUE_APP_SERVER_URL,
  APP_NAME: "Energy measurement",
};
