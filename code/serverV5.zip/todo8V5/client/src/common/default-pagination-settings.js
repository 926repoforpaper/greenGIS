export default {
  page: 1,
  itemsPerPage: 10,
};
