export default {
  "items-per-page-options": [10, 25, 100, -1],
};
