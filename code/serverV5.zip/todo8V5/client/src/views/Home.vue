<template>
  <v-container>
    <h1 class="text-center">Welcome to Energy measurement</h1>
  </v-container>
</template>
