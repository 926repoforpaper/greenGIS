package es.udc.lbd.gema.lps.model.repository;

public interface _repositoriesBasePackage {}
