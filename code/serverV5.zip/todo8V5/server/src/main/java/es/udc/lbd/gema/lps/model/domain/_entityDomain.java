package es.udc.lbd.gema.lps.model.domain;

public interface _entityDomain {}
