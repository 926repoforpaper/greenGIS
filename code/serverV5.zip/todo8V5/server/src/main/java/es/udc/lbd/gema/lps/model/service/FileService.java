package es.udc.lbd.gema.lps.model.service;

import java.io.IOException;

public interface FileService {
  public void writeSpatialFiles() throws IOException;
}
