package es.udc.lbd.gema.lps.web.rest.util.specification_utils;

public enum LogicalOperation {
  AND,
  OR
}
