package es.udc.lbd.gema.lps.component.logger;

public enum Level {
  DEBUG,
  INFO,
  WARN,
  ERROR,
  TRACE
}
