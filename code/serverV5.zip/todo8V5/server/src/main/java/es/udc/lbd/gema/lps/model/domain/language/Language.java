package es.udc.lbd.gema.lps.model.domain.language;

public enum Language {
  EN,
  ES,
  GL,
}
